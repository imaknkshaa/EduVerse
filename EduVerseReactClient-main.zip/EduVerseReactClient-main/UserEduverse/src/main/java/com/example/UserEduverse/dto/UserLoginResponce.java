package com.example.UserEduverse.dto;


import com.example.UserEduverse.model.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserLoginResponce {

	private User user;
	private String jwtToken;
	

}

