package com.example.UserEduverse.model;

public enum USER_ROLE {
    USER,
    ADMIN,
    INSTRUCTOR
}


