import React from 'react'

const CrudNotes = () => {
  return (
    <div>CrudNotes</div>
  )
}

export default CrudNotes