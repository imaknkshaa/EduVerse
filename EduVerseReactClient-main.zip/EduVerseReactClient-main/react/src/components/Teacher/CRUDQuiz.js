import React from 'react'

const CrudQuiz = () => {
  return (
    <div>CrudQuiz</div>
  )
}

export default CrudQuiz