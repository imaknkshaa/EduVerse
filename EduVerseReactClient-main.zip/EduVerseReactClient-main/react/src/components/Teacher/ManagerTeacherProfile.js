import React from 'react'

const ManagerTeacherProfile = () => {
  return (
    <div>ManagerTeacherProfile</div>
  )
}

export default ManagerTeacherProfile