import React from 'react'

const Quiz = () => {
  return (
    <div>AttemptQuiz</div>
  )
}

export default Quiz